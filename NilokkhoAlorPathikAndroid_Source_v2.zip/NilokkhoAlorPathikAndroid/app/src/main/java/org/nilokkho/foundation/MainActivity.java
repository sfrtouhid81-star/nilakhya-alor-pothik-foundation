package org.nilokkho.foundation;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.Patterns;
import android.view.Gravity;
import android.widget.*;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import android.util.Base64;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int GREEN=Color.rgb(5,78,51), DARK=Color.rgb(3,58,39);
    private final int GOLD=Color.rgb(218,181,91), PALE=Color.rgb(244,247,243);
    private LinearLayout root, content;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("foundation_data",MODE_PRIVATE);
        getWindow().setStatusBarColor(DARK); getWindow().setNavigationBarColor(DARK);
        if(prefs.getBoolean("logged_in",false)) showDashboard(); else showWelcome();
    }
    private GradientDrawable shape(int color,int radius,int stroke) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if(stroke>0)d.setStroke(1,stroke); return d;
    }
    private TextView txt(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(4,7,4,7); return t;
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private void base(String subtitle) {
        root=col();root.setBackgroundColor(PALE);
        LinearLayout header=col();header.setPadding(18,13,18,13);header.setBackgroundColor(GREEN);
        header.addView(txt("নিলক্ষ আলোর পথিক ফাউন্ডেশন",19,Color.WHITE,true));
        header.addView(txt(subtitle,12,Color.rgb(236,225,190),false));root.addView(header);
        ScrollView sc=new ScrollView(this);content=col();content.setPadding(17,16,17,22);sc.addView(content);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    private void section(String title) {
        TextView t=txt(title,19,GREEN,true); t.setPadding(3,12,3,12); content.addView(t);
    }
    private EditText field(String hint,int type) {
        EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setSingleLine(true);
        e.setInputType(type);e.setPadding(15,11,15,11);e.setBackground(shape(Color.WHITE,16,Color.rgb(205,216,207)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=11;content.addView(e,p);return e;
    }
    private void button(String label,Runnable run) {
        Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(15);
        b.setAllCaps(false);b.setBackground(shape(GREEN,18,0));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=6;p.bottomMargin=8;
        content.addView(b,p);b.setOnClickListener(v->run.run());
    }
    private void link(String label,Runnable run) {
        TextView t=txt(label,14,GREEN,true);t.setGravity(Gravity.CENTER);content.addView(t);
        t.setOnClickListener(v->run.run());
    }
    private void card(String emoji,String title,String detail,Runnable run) {
        LinearLayout c=col();c.setPadding(15,13,15,13);c.setBackground(shape(Color.WHITE,20,0));
        c.addView(txt(emoji+"  "+title,17,GREEN,true));c.addView(txt(detail,12,Color.DKGRAY,false));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=10;content.addView(c,p);
        c.setOnClickListener(v->run.run());
    }
    private void showWelcome() {
        base("একটি অরাজনৈতিক সেবা প্রতিষ্ঠান");
        LinearLayout hero=col();hero.setPadding(16,25,16,25);hero.setGravity(Gravity.CENTER);
        hero.setBackground(shape(DARK,30,0));
        TextView h=txt("নিলক্ষ আলোর পথিক ফাউন্ডেশন",23,Color.WHITE,true);h.setGravity(Gravity.CENTER);hero.addView(h);
        TextView s=txt("মানবসেবাই আমাদের উদ্দেশ্য",17,GOLD,false);s.setGravity(Gravity.CENTER);hero.addView(s);
        TextView s2=txt("মানবসেবায় আমাদের সঙ্গে যুক্ত হোন।",14,Color.WHITE,false);s2.setGravity(Gravity.CENTER);hero.addView(s2);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.bottomMargin=15;content.addView(hero,hp);
        card("👥","সদস্য নিবন্ধন","নতুন অ্যাকাউন্ট খুলুন",this::showRegister);
        card("🔐","সদস্য লগইন","আগে অ্যাকাউন্ট খুলে থাকলে লগইন করুন",this::showLogin);
        card("📢","নোটিশ বোর্ড","ফাউন্ডেশনের বিজ্ঞপ্তি",this::showNotices);
        TextView footer=txt("স্থাপিত: মে ২০২৩\nনিলক্ষ আলোর পথিক ফাউন্ডেশন\nFB Page: MTowhid 22",13,Color.GRAY,false);
        footer.setGravity(Gravity.CENTER);footer.setPadding(4,24,4,15);content.addView(footer);
    }
    private void showRegister() {
        base("সদস্য নিবন্ধন");
        section("📝 সদস্য নিবন্ধন");
        EditText name=field("পূর্ণ নাম",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText email=field("আপনার Gmail",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText phone=field("মোবাইল নম্বর",InputType.TYPE_CLASS_PHONE);
        EditText address=field("সম্পূর্ণ ঠিকানা",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        EditText pass=field("পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        button("নতুন অ্যাকাউন্ট খুলুন",()->{
            String n=name.getText().toString().trim(), em=email.getText().toString().trim().toLowerCase();
            String ph=phone.getText().toString().trim(), ad=address.getText().toString().trim(), pw=pass.getText().toString();
            if(n.isEmpty()||em.isEmpty()||ph.isEmpty()||ad.isEmpty()||pw.isEmpty()){
                toast("সব তথ্য পূরণ করুন");return;
            }
            if(!Patterns.EMAIL_ADDRESS.matcher(em).matches()){toast("সঠিক ই-মেইল দিন");return;}
            if(pw.length()<6){toast("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে");return;}
            if(prefs.contains("email")){toast("এই ফোনে ইতিমধ্যে একটি সদস্য অ্যাকাউন্ট আছে");return;}
            try {
                byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);
                String hash=hashPassword(pw,salt);
                prefs.edit().putString("member_name",n).putString("email",em).putString("phone",ph)
                    .putString("address",ad).putString("salt",Base64.encodeToString(salt,Base64.NO_WRAP))
                    .putString("password_hash",hash).apply();
                toast("অ্যাকাউন্ট তৈরি হয়েছে। এবার লগইন করুন।");showLogin();
            }catch(Exception ex){toast("অ্যাকাউন্ট তৈরি করা যায়নি");}
        });
        link("আগে অ্যাকাউন্ট আছে? লগইন করুন",this::showLogin);
        link("হোমে ফিরে যান",this::showWelcome);
        content.addView(txt("নিরাপত্তা: এই প্রাথমিক সংস্করণে অ্যাকাউন্টের তথ্য শুধু এই ফোনে থাকবে। অ্যাপের ডেটা মুছে গেলে অ্যাকাউন্টও মুছে যেতে পারে।",12,Color.DKGRAY,false));
    }
    private String hashPassword(String password,byte[] salt)throws Exception{
        PBEKeySpec spec=new PBEKeySpec(password.toCharArray(),salt,120000,256);
        byte[] out=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).getEncoded();
        spec.clearPassword();return Base64.encodeToString(out,Base64.NO_WRAP);
    }
    private void showLogin() {
        base("সদস্য লগইন");
        section("🔐 সদস্য লগইন");
        EditText email=field("আপনার Gmail",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText pass=field("পাসওয়ার্ড",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        button("লগইন করুন",()->{
            String em=email.getText().toString().trim().toLowerCase(), pw=pass.getText().toString();
            if(!prefs.contains("email")){toast("আগে নতুন অ্যাকাউন্ট খুলুন");return;}
            try{
                byte[] salt=Base64.decode(prefs.getString("salt",""),Base64.NO_WRAP);
                String hash=hashPassword(pw,salt);
                if(em.equals(prefs.getString("email",""))&&hash.equals(prefs.getString("password_hash",""))){
                    prefs.edit().putBoolean("logged_in",true).apply();toast("লগইন সফল");showDashboard();
                }else toast("ই-মেইল অথবা পাসওয়ার্ড সঠিক নয়");
            }catch(Exception ex){toast("লগইন করা যায়নি");}
        });
        link("নতুন সদস্য? অ্যাকাউন্ট খুলুন",this::showRegister);
        link("হোমে ফিরে যান",this::showWelcome);
    }
    private void showDashboard() {
        base("সদস্য ড্যাশবোর্ড");
        String name=prefs.getString("member_name","সদস্য");
        section("স্বাগতম, "+name);
        content.addView(txt("মানবসেবায় আমাদের সঙ্গে যুক্ত থাকার জন্য ধন্যবাদ।",14,DARK,false));
        card("👥","সদস্য নিবন্ধন","আপনার সদস্য অ্যাকাউন্ট",()->showProfile());
        card("🙏","অনুদান","অনুদানের তথ্য জমা দিন",()->showServiceForm("অনুদান","অনুদানের পরিমাণ","মন্তব্য"));
        card("🩸","রক্তদাতা","রক্তদাতা হিসেবে তথ্য দিন",()->showServiceForm("রক্তদাতা নিবন্ধন","রক্তের গ্রুপ","এলাকা"));
        card("📚","শিক্ষা সহায়তা","শিক্ষা সহায়তার আবেদন",()->showServiceForm("শিক্ষা সহায়তা","প্রতিষ্ঠানের নাম","সহায়তার বিবরণ"));
        card("🩺","চিকিৎসা সহায়তা","চিকিৎসা সহায়তার আবেদন",()->showServiceForm("চিকিৎসা সহায়তা","এলাকা","সহায়তার বিবরণ"));
        card("❤️","মানবিক সহায়তা","মানবিক সহায়তার আবেদন",()->showServiceForm("মানবিক সহায়তা","এলাকা","সহায়তার বিবরণ"));
        card("📢","নোটিশ বোর্ড","ফাউন্ডেশনের বিজ্ঞপ্তি দেখুন",this::showNotices);
        card("📋","আমার আবেদন","এই ফোনে জমা দেওয়া আবেদন",this::showRecords);
        button("লগআউট",()->{prefs.edit().putBoolean("logged_in",false).apply();showWelcome();});
    }
    private void showProfile() {
        base("সদস্যের তথ্য");section("আপনার অ্যাকাউন্ট");
        content.addView(txt("নাম: "+prefs.getString("member_name",""),15,DARK,false));
        content.addView(txt("Gmail: "+prefs.getString("email",""),15,DARK,false));
        content.addView(txt("মোবাইল: "+prefs.getString("phone",""),15,DARK,false));
        content.addView(txt("ঠিকানা: "+prefs.getString("address",""),15,DARK,false));
        button("ড্যাশবোর্ডে ফিরুন",this::showDashboard);
    }
    private void showServiceForm(String type,String hint1,String hint2) {
        base(type);section(type+" ফর্ম");
        EditText a=field("পূর্ণ নাম (অ্যাকাউন্ট থেকে): "+prefs.getString("member_name",""),InputType.TYPE_CLASS_TEXT);
        a.setText(prefs.getString("member_name",""));
        EditText b=field(hint1,InputType.TYPE_CLASS_TEXT);
        EditText c=field(hint2,InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        button("তথ্য জমা দিন",()->{
            if(b.getText().toString().trim().isEmpty()){toast("প্রয়োজনীয় তথ্য পূরণ করুন");return;}
            try{
                JSONArray arr=new JSONArray(prefs.getString("records","[]"));JSONObject o=new JSONObject();
                o.put("type",type);o.put("name",a.getText().toString());o.put("detail1",b.getText().toString());
                o.put("detail2",c.getText().toString());o.put("date",new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date()));
                arr.put(o);prefs.edit().putString("records",arr.toString()).apply();
                toast("তথ্য এই ফোনে সংরক্ষিত হয়েছে");showRecords();
            }catch(Exception ex){toast("সংরক্ষণ করা যায়নি");}
        });
        button("ফিরে যান",this::showDashboard);
    }
    private void showRecords() {
        base("আমার আবেদন");section("জমা দেওয়া তথ্য");
        try{
            JSONArray a=new JSONArray(prefs.getString("records","[]"));
            if(a.length()==0)content.addView(txt("এখনো কোনো আবেদন জমা হয়নি।",14,Color.DKGRAY,false));
            for(int i=a.length()-1;i>=0;i--){
                JSONObject o=a.getJSONObject(i);card("📄",o.optString("type"),
                    o.optString("name")+" • "+o.optString("detail1")+" • "+o.optString("date"),()->{});
            }
        }catch(Exception e){content.addView(txt("রেকর্ড দেখানো যাচ্ছে না",14,Color.RED,false));}
        button("ড্যাশবোর্ডে ফিরুন",this::showDashboard);
        content.addView(txt("এই রেকর্ড শুধু এই ফোনে সংরক্ষিত।",12,Color.GRAY,false));
    }
    private void showNotices() {
        base("নোটিশ বোর্ড");section("📢 নোটিশ বোর্ড");
        card("📣","ফাউন্ডেশনের বিজ্ঞপ্তি","ফাউন্ডেশনের সকল বিজ্ঞপ্তি এখানে প্রকাশ করা হবে।",()->{});
        content.addView(txt("বর্তমানে কোনো নতুন বিজ্ঞপ্তি যোগ করা হয়নি।",13,Color.DKGRAY,false));
        button(prefs.getBoolean("logged_in",false)?"ড্যাশবোর্ডে ফিরুন":"হোমে ফিরুন",
            ()->{if(prefs.getBoolean("logged_in",false))showDashboard();else showWelcome();});
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
